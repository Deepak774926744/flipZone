  <!--footer begin -->
       <footer>
           
           <div class="icon py-4">
           <h4 class="text-center text-capitalize">follow us on</h4>
           <a href="#">
          <i class="fab fa-facebook"></i>
          </a>
              <a href="#">
           <i class="fas fa-envelope"></i>
           </a>
           <a href="#">
          <i class="fab fa-twitter"></i>
          </a>
          <a href="#">
          <i class="fab fa-instagram"></i>
          </a>
          <a href="#">
          <i class="fab fa-google-plus-g"></i>
          </a>
        
           </div>
           <div class="info">
               <h4 class="text-center text-capitalize">contact</h4>
           </div>
           <div class="info-data">
               <span><i class="fas fa-phone"></i></span> +91 790 529 2740
               
               
           </div>
           <div class="copyright">
               
               <h2 class="text-center ">Copyright &copy; 2019  <span class="footer-logo">flipZone </span>- All Right Reserved.</h2>
               
               
           </div>
           
           
           
           
           
           
           
       </footer>
       
       
       
       
       
       
       
       
       
       <!-- footer end-->
       